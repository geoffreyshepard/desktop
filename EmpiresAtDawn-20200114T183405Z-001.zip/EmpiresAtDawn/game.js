var Civilization = function(name, pwood, pfood, pstone){
	this.name = name || "civilization",
	this.pwood = pwood || 0,
	this.pfood = pfood || 0,
	this.pstone = pstone || 0
}

var Eygpt = new Civilization("Eygpt",0,1.25,1.5);