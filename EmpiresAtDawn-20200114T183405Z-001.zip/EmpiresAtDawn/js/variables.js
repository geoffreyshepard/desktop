//base Cost prototype for all costs in all buildings, units, actions, etc.
var costPrototype = {
	wood			: 0,
	food			: 0,
	stone			: 0,
	herbs 			: 0,
	fur 			: 0,
	ore 			: 0
}

/*---------------*/

//template for player resources and implmentation
var resoucePrototype = {
	current 		: 100,
	max 			: 100,
	increment 		: 1,
	multiplier 		: 1,
	percent			: 50,
	production 		: 0

};

var starvationPrototype = {
	current			: false,
	hours 			: 0
}

//initalizes new player resources with resourcePrototype template
var playerResourcesPrototype = {
	wood 			: Object.create(resoucePrototype),
	food 			: Object.create(resoucePrototype),
	stone 			: Object.create(resoucePrototype),
	herbs 			: Object.create(resoucePrototype),
	fur				: Object.create(resoucePrototype),
	ore	 			: Object.create(resoucePrototype),
};

/*---------------*/

//housing prototype for capacity and multipiers
var buildingsHousingPrototype = {
	current 		: 0,
	capacity		: 0,
	cost			: Object.create(costPrototype),
	objectArray		: [1,5,10,25,50,100,500,1000],
	name 			: "default"
}
var buildingsProductionPrototype = {
	current 		: 0,
	multiplier 		: 1,
	outputWood		: 0,
	outputFood		: 0,
	outputStone		: 0,
	outputHerbs		: 0,
	outputFur		: 0,
	outputOre		: 0,
	cost			: Object.create(costPrototype),
	employment 		: 0
}
var playerBuildingsPrototype = {
	hut				: Object.create(buildingsHousingPrototype),
	loghouse		: Object.create(buildingsHousingPrototype),
	brickhouse		: Object.create(buildingsHousingPrototype),
	manor			: Object.create(buildingsHousingPrototype),

	gatheringhut	: Object.create(buildingsProductionPrototype),
	huntinglodge	: Object.create(buildingsProductionPrototype),
	farmwheat		: Object.create(buildingsProductionPrototype),

	logginghut		: Object.create(buildingsProductionPrototype),
	lumbermill		: Object.create(buildingsProductionPrototype),
	lumberyard		: Object.create(buildingsProductionPrototype),

	stoneyard		: Object.create(buildingsProductionPrototype),
	quarry			: Object.create(buildingsProductionPrototype),
	mine			: Object.create(buildingsProductionPrototype),
};

var playerTimePrototype ={
	hour 			: 1,
	day				: 1,
	month 			: 1,
	year 			: 1
}

//basic variables that a civilization has
var civilizationPrototype = {
	type 			: "default",
	locationX		: 1,
	locationY		: 1,
	perkWood 		: null,
	perkFood 		: null,
	perkStone 		: null,
	population		: 0,
	unemployed		: 0,
	employed		: 0,
	capacity		: 0,
	starving		: Object.create(starvationPrototype),
	desire			: 0
};


/*---------------*/

//master template for a player
var p = {
	civilization 	: Object.create(civilizationPrototype),
	resources 		: Object.create(playerResourcesPrototype),
	buildings		: Object.create(playerBuildingsPrototype),
	playedBefore	: false,
	time 			: Object.create(playerTimePrototype),
}

//each time a employment building is added to the game it needs to go into this array
p.employmentArray = [p.buildings.gatheringhut, p.buildings.huntinglodge, p.buildings.farmwheat, 
p.buildings.logginghut, p.buildings.lumbermill, p.buildings.lumberyard, p.buildings.stoneyard, 
p.buildings.quarry, p.buildings.mine];

//each time a resource is added to the game it needs to go in order to this array
p.resourceArray	= [p.resources.food, p.resources.wood, p.resources.stone, p.resources.ore, p.resources.herbs, p.resources.fur];
p.progressHTMLArray = [".progress-food", ".progress-wood",	".progress-stone", ".progress-ore", ".progress-herbs",".progress-fur"];
p.rateHTMLArray = [".food-rate", ".wood-rate", ".stone-rate", ".ore-rate", ".herbs-rate", ".fur-rate"];

//declares the players starting variables
p.civilization.desire 					= 10;

// HOUSING
//hut
p.buildings.hut.name					= "hut";
p.buildings.hut.current					= 2;
p.buildings.hut.cost.food 				= 25;
p.buildings.hut.cost.wood 				= 50;
p.buildings.hut.cost.stone 				= 10;
p.buildings.hut.capacity				= 1;

//loghouse
p.buildings.loghouse.name				= "loghouse";
p.buildings.loghouse.cost.food 			= 25;
p.buildings.loghouse.cost.wood 			= 50;
p.buildings.loghouse.cost.stone 		= 10;
p.buildings.loghouse.capacity			= 3;

//brickhouse
p.buildings.brickhouse.name				= "brickhouse";
p.buildings.brickhouse.cost.food 		= 25;
p.buildings.brickhouse.cost.wood 		= 50;
p.buildings.brickhouse.cost.stone 		= 10;
p.buildings.brickhouse.capacity			= 10;

//manor
p.buildings.manor.name					= "manor";
p.buildings.manor.cost.food 			= 25;
p.buildings.manor.cost.wood 			= 50;
p.buildings.manor.cost.stone 			= 10;
p.buildings.manor.capacity				= 50;

// FOOD PRODUCTION BUILDINGS
//gatheringhut
p.buildings.gatheringhut.name			= "gatheringhut";
p.buildings.gatheringhut.cost.food 		= 35;
p.buildings.gatheringhut.cost.wood 		= 35;
p.buildings.gatheringhut.cost.stone 	= 15;
p.buildings.gatheringhut.multiplier 	= .1;

//huntinglodge
p.buildings.huntinglodge.name			= "huntinglodge";
p.buildings.huntinglodge.cost.food 		= 35;
p.buildings.huntinglodge.cost.wood 		= 35;
p.buildings.huntinglodge.cost.stone 	= 15;
p.buildings.huntinglodge.multiplier 	= .3;

//farmwheat
p.buildings.farmwheat.name				= "farmwheat";
p.buildings.farmwheat.cost.food 		= 35;
p.buildings.farmwheat.cost.wood 		= 35;
p.buildings.farmwheat.cost.stone 		= 15;
p.buildings.farmwheat.multiplier 	 	= 1;

// WOOD PRODUCTION BUILDINGS
//logginghut
p.buildings.logginghut.name				= "logginghut";
p.buildings.logginghut.cost.food 		= 25;
p.buildings.logginghut.cost.wood 		= 75;
p.buildings.logginghut.cost.stone 		= 25;













