function foodProduction(){
	p.buildings.gatheringhut.outputFood = p.buildings.gatheringhut.current * p.buildings.gatheringhut.multiplier;
	p.buildings.huntinglodge.outputFood = p.buildings.huntinglodge.current * p.buildings.huntinglodge.multiplier;
	p.buildings.farmwheat.outputFood = p.buildings.farmwheat.current * p.buildings.farmwheat.multiplier;

	p.resources.food.production = ( p.buildings.gatheringhut.outputFood + p.buildings.huntinglodge.outputFood + p.buildings.farmwheat.outputFood );
	p.resources.food.production -= foodConsumption();
}

function foodConsumption(){
	//function to create food consumption, gets returned to foodProduction()
	//each person in total population eats .1 food per hour
	var x = (p.civilization.population * .1);
	return x;
}












function generateProduction(){
	foodProduction();


	p.resources.food.current += p.resources.food.production;

	//player resources array
	var r= p.resourceArray;
	var rateHTML = p.rateHTMLArray;

	//displays the rates on resources
	for(var i = 0; i < r.length; i++){
		var temp = r[i].production
		$(rateHTML[i]).html(r[i].production.toFixed(1));

		if(r[i].production < 0)	$(rateHTML[i]).css("color", "#cc3333").css("font-weight", "bold");
		if(r[i].production >= 0)	$(rateHTML[i]).css("color", "#fff").css("font-weight", "normal");
	}
}