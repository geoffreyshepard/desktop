// ------------------------------ //

//manual gathering of resources
function manualResourceUpdate(resourceType){
	resourceType.current += resourceType.increment;
	//checks to see if resources current is greater than the max amount allowed
	if (resourceType.current > resourceType.max){
		resourceType.current = resourceType.max;
	}
	loadResources();
}

$(".btn-food").click(function(){manualResourceUpdate(p.resources.food);});
$(".btn-wood").click(function(){manualResourceUpdate(p.resources.wood);});
$(".btn-stone").click(function(){manualResourceUpdate(p.resources.stone);});

// ------------------------------ //

function changeIncrement(direction, buildButton, type){
	//direction   : if we are increasing or decreasing the build amount
	//buildButton : what button data-value we are changing (construction quantity)
	//type 		  : what are we constructing within the players variables (buidlings, military, research, etc.)
	var increment = $(buildButton).data("increment");
	var value = $(buildButton).data("value");
	var objectString = $(buildButton).data("object")
	var object = eval("p." + type + "." + objectString + ".objectArray");

	if(direction == "sub"){
		if(increment > 0){
			increment -= 1;
		}
	}
	else if(direction == "plus"){
		if(increment < 7){
			increment += 1;
		}
	}
	else{console.log("changeIncrement bug");}

	//changes the html, data-increment, & data-value
	$(buildButton).data("increment", increment);
	$(buildButton).data("value", object[increment]);
	$(buildButton).html(object[increment]);
}


$(".hideshowHousing").click(function(){
	if($(".hideshowHousing").html() == "Hide"){
		$("ul.housing-list > li").css("display", "none");
		$(".hideshowHousing").html("show");
	}
	else{
		$("ul.housing-list > li").css("display", "block");
		$(".hideshowHousing").html("Hide");
	}
});
$(".hideshowFoodProduction").click(function(){
	if($(".hideshowFoodProduction").html() == "Hide"){
		$("ul.food-production-list > li").css("display", "none");
		$(".hideshowFoodProduction").html("show");
	}
	else{
		$("ul.food-production-list > li").css("display", "block");
		$(".hideshowFoodProduction").html("Hide");
	}
});

// construction of buildings
// HOUSING
$(".btn-hut-add").click(function(){checkCosts(p.buildings.hut, $(".btn-hut-add").data("value"))});
$(".btn-hut-sub").click(function(){ changeIncrement("sub", ".btn-hut-add", "buildings")});
$(".btn-hut-plus").click(function(){changeIncrement("plus", ".btn-hut-add", "buildings")});

$(".btn-loghouse-add").click(function(){checkCosts(p.buildings.loghouse, $(".btn-loghouse-add").data("value"))});
$(".btn-loghouse-sub").click(function(){ changeIncrement("sub", ".btn-loghouse-add", "buildings")});
$(".btn-loghouse-plus").click(function(){changeIncrement("plus", ".btn-loghouse-add", "buildings")});

$(".btn-brickhouse-add").click(function(){checkCosts(p.buildings.brickhouse, $(".btn-brickhouse-add").data("value"))});
$(".btn-brickhouse-sub").click(function(){ changeIncrement("sub", ".btn-brickhouse-add", "buildings")});
$(".btn-brickhouse-plus").click(function(){changeIncrement("plus", ".btn-brickhouse-add", "buildings")});

$(".btn-manor-add").click(function(){checkCosts(p.buildings.manor, $(".btn-manor-add").data("value"))});
$(".btn-manor-sub").click(function(){ changeIncrement("sub", ".btn-manor-add", "buildings")});
$(".btn-manor-plus").click(function(){changeIncrement("plus", ".btn-manor-add", "buildings")});

// FOOD PRODUCTION
$(".btn-gatheringhut-add").click(function(){checkCosts(p.buildings.gatheringhut, $(".btn-gatheringhut-add").data("value"))});
$(".btn-gatheringhut-sub").click(function(){ changeIncrement("sub", ".btn-gatheringhut-add", "buildings")});
$(".btn-gatheringhut-plus").click(function(){changeIncrement("plus", ".btn-gatheringhut-add", "buildings")});

$(".btn-huntinglodge-add").click(function(){checkCosts(p.buildings.huntinglodge, $(".btn-huntinglodge-add").data("value"))});
$(".btn-huntinglodge-sub").click(function(){ changeIncrement("sub", ".btn-huntinglodge-add", "buildings")});
$(".btn-huntinglodge-plus").click(function(){changeIncrement("plus", ".btn-huntinglodge-add", "buildings")});

$(".btn-farmwheat-add").click(function(){checkCosts(p.buildings.farmwheat, $(".btn-farmwheat-add").data("value"))});
$(".btn-farmwheat-sub").click(function(){ changeIncrement("sub", ".btn-farmwheat-add", "buildings")});
$(".btn-farmwheat-plus").click(function(){changeIncrement("plus", ".btn-farmwheat-add", "buildings")});



// hide show tooltips
$(".btn-buildingdescriptions").click(function(){
	if( $(".building-description").css("display") == "none"){
		$(".building-description").removeClass("hidden");
		$(".building-description").addClass("visible");
	}
	else{
		$(".building-description").removeClass("visible");
		$(".building-description").addClass("hidden");
	}
});




