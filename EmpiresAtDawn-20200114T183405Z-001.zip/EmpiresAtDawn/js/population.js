

function updatePopulation(){

	generateHousing();
	populationStarving();
	newPopulation();
	generateEmployment();
	generateProduction();
	


	//updates the top navigation display of population information
	loadHTML(".unemployedworkers", p.civilization.unemployed);
	loadHTML(".totalpopulation",   p.civilization.population);
	loadHTML(".populationcapacity",   p.civilization.capacity);

	//changes the color to red and font weight to bold if there are unemployed workers
	if(p.civilization.unemployed > 0){
		$(".unemployedworkers").css("color", "#cc3333");
		$(".unemployedworkers").css("font-weight", "bold");
	}
	else{$(".unemployedworkers").css("color", "#fff");$(".unemployedworkers").css("font-weight", "normal");}
}

function generateHousing(){
	//makes  sure that population is within bounds of capacity and not below zero, then generates total housing capacity
	//temp variables to figure out the population capacity
	var tempHut = (p.buildings.hut.current * p.buildings.hut.capacity);
	var tempLoghouse = (p.buildings.loghouse.current * p.buildings.loghouse.capacity);
	var tempBrickhouse = (p.buildings.brickhouse.current * p.buildings.brickhouse.capacity);
	var tempManor = (p.buildings.manor.current * p.buildings.manor.capacity);

	p.civilization.capacity = tempHut + tempLoghouse + tempBrickhouse + tempManor;
}

function generateEmployment(){
	//makes sure employment from buildings and unemployment are correct
	var r = p.employmentArray;
	var tempEmployed = 0;

	//cycles through each buidling and checks employment and adds it to the tempEmployed
	for(var i = 0; i < r.length; i++){
		tempEmployed += r[i].employment;
	}
	p.civilization.employed = tempEmployed;
	p.civilization.unemployed = p.civilization.population - p.civilization.employed;
}

function newPopulation(){
	//can not gain new population if your population is starving (has no food in storage) then if
	//if random number out of 100 is below civilization desire you will gain a new citizen
	//the higher the desire to live in your civilization the quicker it will populate
	if(p.civilization.starving.current == false){
		var immigrant = _.random(0,100);
		if (immigrant < p.civilization.desire) p.civilization.population += 1;
	}


	//makes sure that the population is not above the population capacity from housing
	if(p.civilization.population > p.civilization.capacity) p.civilization.population = p.civilization.capacity;
	//makes sure the population is not below zero
	if(p.civilization.population < 0) p.civilization.population = 0;
}

function populationStarving(){
	if (p.resources.food.current <= 0){
		//if player is starving set bool to true and increment hours of starving
		p.civilization.starving.current = true;
		p.civilization.starving.hours += 1;
		console.log(p.civilization.starving.current + " " + p.civilization.starving.hours);

		//if player has been starving for longer than 12 hours the player will start to lose population
		if(p.civilization.starving.hours > 12){
			p.civilization.population -= 1
		}
	}
	else{
		p.civilization.starving.current = false;
		p.civilization.starving.hours = 0;
	}
}