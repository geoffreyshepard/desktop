$(document).ready(function(){
	if(p.playedBefore == false){
		firstGame();
	}
	loadTime();
	updatePopulation();
	beginTick();
});

function firstGame(){
	loadResources();
}

function beginTick(){
  nIntervId = setInterval(tick, 2500);
}


function tick(){
	updatePopulation();
	updateTime();
	loadResources();
}

function loadHTML(place, value){
	return $(place).html(value);
}







function loadResources(){
	//checks values less than 0, updates all values into HTML elements

	//checks to make sure player does not have a negative amount of resources
	resourcesOutOfBounds();

	//loads all the current player resources and max resources
	loadHTML(".food-current", 	p.resources.food.current.toFixed(1));
	loadHTML(".food-max", 		p.resources.food.max.toFixed(1));
	loadHTML(".wood-current", 	p.resources.wood.current.toFixed(1));
	loadHTML(".wood-max", 		p.resources.wood.max.toFixed(1));
	loadHTML(".stone-current", 	p.resources.stone.current.toFixed(1));
	loadHTML(".stone-max", 		p.resources.stone.max.toFixed(1));
	loadHTML(".herbs-current", 	p.resources.herbs.current.toFixed(1));
	loadHTML(".herbs-max", 		p.resources.herbs.max.toFixed(1));
	loadHTML(".fur-current", 	p.resources.fur.current.toFixed(1));
	loadHTML(".fur-max", 		p.resources.fur.max.toFixed(1));
	loadHTML(".ore-current", 	p.resources.ore.current.toFixed(1));
	loadHTML(".ore-max", 		p.resources.ore.max.toFixed(1));

	//loads the player buildings
	loadHTML(".building-hut", 			p.buildings.hut.current);
	loadHTML(".building-loghouse", 		p.buildings.loghouse.current);
	loadHTML(".building-brickhouse", 	p.buildings.brickhouse.current);
	loadHTML(".building-manor", 		p.buildings.manor.current);
	loadHTML(".building-gatheringhut", 	p.buildings.gatheringhut.current);
	loadHTML(".building-huntinglodge", 	p.buildings.huntinglodge.current);
	loadHTML(".building-farmwheat", 	p.buildings.farmwheat.current);


	//after loading all the values into the Html, now update the associated progress bars
	generateProgressBars();
}

function resourcesOutOfBounds(){
	//checks to make sure that values are not below 0
	if(p.resources.food.current  < 0) p.resources.food.current = 0;
	if(p.resources.wood.current  < 0) p.resources.wood.current = 0;
	if(p.resources.stone.current < 0) p.resources.stone.current = 0;
	if(p.resources.ore.current   < 0) p.resources.ore.current = 0;
	if(p.resources.herbs.current < 0) p.resources.herbs.current = 0;
	if(p.resources.fur.current   < 0) p.resources.fur.current = 0; 

	//checks to make sure than current resources can not go above storage
	if(p.resources.food.current  >= p.resources.food.max) p.resources.food.current   = p.resources.food.max;
	if(p.resources.wood.current  >= p.resources.wood.max) p.resources.wood.current   = p.resources.wood.max;
	if(p.resources.stone.current >= p.resources.stone.max) p.resources.stone.current = p.resources.stone.max;
	if(p.resources.ore.current   >= p.resources.ore.max) p.resources.ore.current     = p.resources.ore.max;
	if(p.resources.herbs.current >= p.resources.herbs.max) p.resources.herbs.current = p.resources.herbs.max;
	if(p.resources.fur.current   >= p.resources.fur.max) p.resources.fur.current     = p.resources.fur.max; 	
}

function generateProgressBars(){
	//updates the progress bars across the game

	//temp variable to loop through all player resources
	var r= p.resourceArray;

	//span classes of progress bars that we need to update, has to be in the same position are the var "r" above
	var html = p.progressHTMLArray;
	
	//loops through all player resources and figures out the percent width of the progress bar and updates it
	for(var i = 0; i < r.length; i++){
		var temp = (r[i].current/r[i].max) * 100;
		temp = parseInt(temp);
		r[i].percent = temp;
		$(html[i]).css("width", r[i].percent + "%").attr("aria-value", r[i].percent);

		//changes color of meter based on how low percent of storage you have
		if( r[i].percent <= 25 ) $(html[i]).css("background", "#cc3333");
		if( r[i].percent > 25 && r[i].percent <= 49) $(html[i]).css("background", "#faa824");
		if( r[i].percent >= 50 && r[i].percent <= 74 ) $(html[i]).css("background", "#5fc9df");
		if( r[i].percent > 74 	) $(html[i]).css("background", "#61B329");
	}
}




function checkCosts(x, amount){
	//check to make sure player has enough resources for object being sent in
	if( p.resources.food.current  	>= (x.cost.food * amount)  && 
		p.resources.wood.current 	>= (x.cost.wood * amount)  && 
		p.resources.stone.current 	>= (x.cost.stone * amount) && 
		p.resources.ore.current 	>= (x.cost.ore * amount)   && 
		p.resources.herbs.current 	>= (x.cost.herbs * amount) && 
		p.resources.fur.current 	>= (x.cost.fur * amount)
		){
			p.resources.food.current  	-= (x.cost.food  * amount);
			p.resources.wood.current 	-= (x.cost.wood  * amount);
			p.resources.stone.current 	-= (x.cost.stone * amount);
			p.resources.ore.current 	-= (x.cost.ore   * amount);
			p.resources.herbs.current 	-= (x.cost.herbs * amount);
			p.resources.fur.current 	-= (x.cost.fur   * amount);
			loadResources();
			//constructs the object being sent in
			x.current += amount;
			loadResources();
			console.log("you built " + amount + " " + x.name + " and have " + x.current + " now");
		}
	else{
		//displays the alert in the bottom right corner when you do not have enough resources
		$(".notification").html("You do not have enough resources to build " + amount + " " + x.name + "(s)");
		$(".notification-alert").fadeIn(250);
		$(".notification").fadeIn(250);
		$(".notification-alert").delay(3000).fadeOut(250);
		$(".notification").delay(3000).fadeOut(250);

		//tells you all the value
		console.log("object costs " + (x.cost.food   * amount)+ " food you have " +   p.resources.food.current);
		console.log("object costs " + (x.cost.wood   * amount)+ " wood you have " +   p.resources.wood.current);
		console.log("object costs " + (x.cost.stone  * amount)+ " stone you have " + p.resources.stone.current);
		console.log("object costs " + (x.cost.herbs  * amount)+ " herbs you have " + p.resources.herbs.current);
		console.log("object costs " + (x.cost.ore    * amount)+ " ore you have " +     p.resources.ore.current);
		console.log("object costs " + (x.cost.fur    * amount)+ " fur you have " +     p.resources.fur.current);
	}

}




/*******  TIMING FUNCTIONS *******/
function loadTime(){
	//updates the html of the time variables
	loadHTML(".hour", p.time.hour);
	loadHTML(".day", p.time.day);
	loadHTML(".month", p.time.month);
	loadHTML(".year", p.time.year);
}

function updateTime(){
	//increments the time along hours, days, months, years
	p.time.hour += 1;
	if(p.time.hour == 25){
		p.time.hour = 1;
		p.time.day += 1;
		if(p.time.day == 31){
			p.time.day = 1;
			p.time.month += 1;
			if(p.time.month == 13){
				p.time.month = 1;
				p.time.year += 1;
			}
		}
	}
	loadTime();
}